//
//  CoreDataAppoiment+CoreDataClass.swift
//  
//
//  Created by Bhavin Kevadia on 15/09/22.
//
//

import Foundation
import CoreData

@objc(CoreDataAppoiment)
public class CoreDataAppoiment: NSManagedObject {

}
